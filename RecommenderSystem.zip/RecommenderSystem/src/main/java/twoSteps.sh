./run.sh
./runJava.sh

